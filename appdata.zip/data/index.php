 <?php 
 header('location:../../data/pages/index.php');
    exit();

     ?>