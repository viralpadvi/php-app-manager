 <?php 
 header('location:ewfrwer');
    exit();

     ?>