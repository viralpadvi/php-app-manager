<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 

echo $_POST['firstname'];
echo $_POST['lastname'];

 ?>
</body>
</html>