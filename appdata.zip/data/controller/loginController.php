<?php 
session_start();
include_once '../lib/dao.php';
include_once '../lib/model.php';
// create a is_object
$d = new dao();
$m = new model();

header('Access-Control-Allow-Origin: *');  //I have also tried the * wildcard and get the same response
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('content-type: application/json; charset=utf-8');
header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');


extract($_POST);
extract($_GET);
$response = array();
/*
if(isset($mobile)){

	$q=$d->select("users","mobile='$mobile' AND password='$password'");
	$row = mysqli_fetch_array($q);
	
	if($row==TRUE) {
		 $response["user_id"]= $row['user_id'];
		 $response["full_name"]= $row['full_name'];
		 $response["mobile"]= $row['mobile'];
		 $response["message"] = "Login successfully.";
		 $response["status"]=1;
		 echo json_encode($response);
	} else {
		 $response["message"] = "Wrong Mobile Or Password";
		 $response["status"]=0;
		 echo json_encode($response);
	}
}
*/

/*if(isset($username)){

	$q=$d->select("admin","ad_username='$username' AND ad_password='$password'");
	$row = mysqli_fetch_array($q);
	
	if($row==TRUE) {
		 $_SESSION['ad_id']= $row['ad_id'];
		 $_SESSION['ad_username']= $row['ad_username'];
		 header("location:index.php?success=Welcome");
		 
	} else {
		 header("location:login.php?erromsg=Wrong Details");
	}
}
*/
 echo "not valid your id/psw";
 

if(isset($_POST['loginemail'])){
	   $loginemail=$_POST['loginemail'];
	   $password=$_POST['password'];
	$q=$d->select("admin","name='$loginemail'and password='$password'");
	$data=mysqli_fetch_array($q);
	
	if ($data>0) {
		$_SESSION['admin_id']=$data['admin_id'];
		$_SESSION['name']=$data['name'];
		$_SESSION['email']=$data['email'];
		header("location:../../data/pages/index");
	}else{
		header("location:login?msgError=wrong details");
	}
}
?>