-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2018 at 07:38 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appdev`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_group_id`
--

CREATE TABLE `add_group_id` (
  `id` int(11) NOT NULL,
  `group_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_group_id`
--

INSERT INTO `add_group_id` (`id`, `group_id`) VALUES
(3, 'gp_20181006121022');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `email`, `password`) VALUES
(5, 'admin', 'admin12@gmail.com', 'admin3004');

-- --------------------------------------------------------

--
-- Table structure for table `appdata`
--

CREATE TABLE `appdata` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `yturl` varchar(300) NOT NULL,
  `ytimg` varchar(200) NOT NULL,
  `time` time NOT NULL,
  `length` int(11) NOT NULL,
  `views` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `c_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appdata`
--

INSERT INTO `appdata` (`id`, `name`, `yturl`, `ytimg`, `time`, `length`, `views`, `status`, `c_name`, `c_id`) VALUES
(1, 'abc', 'https://www.youtube.com/watch?v=xbIz4lGDZUQ', '', '00:00:00', 0, 0, 0, '0', 0),
(2, 'abc', 'https://www.youtube.com/watch?v=Ipa9xAs_nTg', '', '00:00:00', 0, 0, 0, '0', 0),
(3, 'dsfdf', 'https://www.youtube.com/watch?v=Ipa9xAs_nTg', 'pakistanflag.png', '00:00:00', 0, 0, 0, 'Gujarati', 0),
(4, 'data', 'https://www.youtube.com/watch?v=vHrbvH-5cso', 'happy_birthday_photo_frame_background_vector_549182.jpg', '00:00:00', 0, 0, 0, 'Punjabi', 0),
(5, 'abcd', 'https://www.youtube.com/watch?v=vHrbvH-5cso', 'traffic_light_project_management_business_office_working-512.png', '00:00:00', 0, 0, 0, 'Love', 0),
(6, 'viral padvi', 'https://www.youtube.com/watch?v=vHrbvH-5cso', 'affiliate_show_banner.php_180-e1328512765947.jpg', '00:00:00', 0, 0, 0, '6', 0),
(7, 'name', 'https://www.youtube.com/watch?v=vHrbvH-5cso', 'americaflg.png', '00:00:00', 0, 0, 0, '', 0),
(8, 'dsfdf', 'https://www.youtube.com/watch?v=Ipa9xAs_nTg', 'indiaflag.png', '00:00:00', 0, 0, 0, '12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `appdetails`
--

CREATE TABLE `appdetails` (
  `pkg_name` varchar(300) NOT NULL,
  `id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `developer_ac` varchar(100) NOT NULL,
  `app_name` varchar(200) NOT NULL,
  `short_desc` varchar(200) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `promo_video_id` varchar(200) NOT NULL,
  `version_code` varchar(200) NOT NULL,
  `version_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `app_icon` varchar(200) NOT NULL,
  `app_banner` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `AD` int(11) NOT NULL DEFAULT '0',
  `downloads` bigint(200) DEFAULT '1',
  `revenuad` int(200) NOT NULL DEFAULT '0',
  `authentication` text,
  `google_initialize_id` varchar(500) DEFAULT NULL,
  `google_banner_id` varchar(500) DEFAULT NULL,
  `google_native_id` varchar(500) DEFAULT NULL,
  `google_inter_id` varchar(500) DEFAULT NULL,
  `fb_banner_id` varchar(500) DEFAULT NULL,
  `fb_native_id` varchar(500) DEFAULT NULL,
  `fb_inter_id` varchar(500) DEFAULT NULL,
  `token` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_category`
--

CREATE TABLE `app_category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_category`
--

INSERT INTO `app_category` (`cat_id`, `cat_name`) VALUES
(1, 'Events'),
(2, 'sds'),
(3, 'sds'),
(4, 'ad'),
(5, 'dfgfgfddfg'),
(6, 'xddf'),
(7, 'dgvsdg'),
(8, 'hello'),
(9, 'cvdvd'),
(10, 'adss'),
(11, 'adsg'),
(12, 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');

-- --------------------------------------------------------

--
-- Table structure for table `app_download_details`
--

CREATE TABLE `app_download_details` (
  `id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `app_name` varchar(100) NOT NULL,
  `downloads` int(11) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_download_details`
--

INSERT INTO `app_download_details` (`id`, `app_id`, `app_name`, `downloads`, `date`) VALUES
(1, 'app-881227845', 'sdfdsf', 34, '12-06-2018'),
(2, 'app-881227845', 'sdfdsf', 36, '12-06-2018');

-- --------------------------------------------------------

--
-- Table structure for table `app_group_cat`
--

CREATE TABLE `app_group_cat` (
  `g_id` int(11) NOT NULL,
  `group_id` varchar(100) NOT NULL,
  `app_ids` varchar(500) NOT NULL,
  `app_open` bigint(100) NOT NULL,
  `impression` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_group_cat`
--

INSERT INTO `app_group_cat` (`g_id`, `group_id`, `app_ids`, `app_open`, `impression`) VALUES
(1, 'gp_20181006121022', 'app-201809131042', 0, 0),
(2, 'gp_20181006121022', 'app-201809261620', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

CREATE TABLE `audio` (
  `id` int(11) NOT NULL,
  `audio_file` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `buslist`
--

CREATE TABLE `buslist` (
  `id` int(11) NOT NULL,
  `Service` varchar(100) NOT NULL,
  `Trip` varchar(100) NOT NULL,
  `Dept` varchar(100) NOT NULL,
  `ServiceStart` varchar(100) NOT NULL,
  `Origin` varchar(100) NOT NULL,
  `Destination` varchar(100) NOT NULL,
  `Journey` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buslist`
--

INSERT INTO `buslist` (`id`, `Service`, `Trip`, `Dept`, `ServiceStart`, `Origin`, `Destination`, `Journey`, `login_id`) VALUES
(0, '1', 'dfsdaf', 'dsg', 'dsg', 'sdgd', 'dgs', 'sdg', 1),
(0, '1', 'dfsdaf', 'dsg', 'dsg', 'sdgd', 'dgs', 'sdg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`) VALUES
(6, 'Love'),
(7, 'Sad'),
(8, 'Romentic'),
(9, 'Punjabi'),
(10, 'Gujarati'),
(11, 'Birthday'),
(12, 'Birthday'),
(13, 'Romentic');

-- --------------------------------------------------------

--
-- Table structure for table `date_filter`
--

CREATE TABLE `date_filter` (
  `id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `download` bigint(20) NOT NULL DEFAULT '0',
  `today_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `date_filter`
--

INSERT INTO `date_filter` (`id`, `app_id`, `download`, `today_date`) VALUES
(1, 'app-201809131042', 5, '2018-09-13'),
(2, 'app-201809131042', 4, '2018-09-13'),
(3, 'app-201809131042', 3, '2018-09-14'),
(4, 'app-201809131042', 2, '2018-09-15');

-- --------------------------------------------------------

--
-- Table structure for table `developer`
--

CREATE TABLE `developer` (
  `dev_id` int(11) NOT NULL,
  `dev_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `developer`
--

INSERT INTO `developer` (`dev_id`, `dev_name`) VALUES
(1, 'JUGADU'),
(2, 'JUSTCOOL'),
(3, 'APPDEVINC'),
(4, 'ad'),
(5, 'ad'),
(6, 'adweqweq'),
(7, 'vdsfdf'),
(8, 'adweqweq'),
(9, 'sdfsdfsdfdfdf'),
(10, 'xcvxcv'),
(11, 'helllo'),
(12, 'adss'),
(13, 'ggg'),
(14, 'adsg'),
(15, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `dynamic_page`
--

CREATE TABLE `dynamic_page` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `short_name` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `link` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dynamic_page`
--

INSERT INTO `dynamic_page` (`id`, `category`, `short_name`, `name`, `link`) VALUES
(1, 'we', 'a', 'ds', 'http://www.phpcodify.com/download/insert-data-php-using-jquery-ajax-source-code/'),
(2, 'sdfsd', 'sdsa', 'asd', 'sad'),
(3, 'dsd', 'sd', 'sd', 'http://www.phpcodify.com/download/insert-data-php-using-jquery-ajax-source-code/'),
(4, 'xdfsdf', 'sdfdsf', 'dsfds', 'dfsdf'),
(5, 'fgfdg', 'dfg', 'dfg', 'fg'),
(6, 'dsf', 'sdf', 'fs', 'aaa'),
(7, 'dsf', 'sdf', 'fs', 'aaa'),
(8, 'dsf', 'sdf', 'fs', 'aaa'),
(9, 'dsf', 'sdf', 'fs', 'aaa'),
(10, 'dsf', 'sdf', 'fs', 'aaa'),
(11, 'sdf', 'ab', 'ab', 'https://www.phpcodify.com/pass-data-to-php-using-ajax-without-page-load/'),
(12, 'sdf', 'df', 'aa', 'http://localhost/phpmyadmin/sql.php?db=appdev&amp;table=dynamic_page&amp;pos=0'),
(13, 'aa', 'aaa', 'aaa', 'http://localhost/phpmyadmin/sql.php?db=appdev&amp;table=dynamic_page&amp;pos=0'),
(14, 'ss', 'ss', 'ss', 'https://www.bing.com/search?form=MO0035&amp;q=file+extension+php'),
(15, 'add', 'add', 'add', 'https://www.bing.com/search?form=MO0035&amp;q=file+extension+php'),
(16, 'as', 'as', 'as', 'https://www.bing.com/search?form=MO0035&amp;q=file+extension+php'),
(17, 'as', 'as', 'as', 'https://www.bing.com/search?form=MO0035&amp;q=file+extension+php'),
(18, 'ewfrwe', 'wwew', 'ewerw', 'https://www.bing.com/search?form=MO0035&amp;q=file+extension+php'),
(19, 'er', 'er', 're', 'https://www.bing.com/search?form=MO0035&amp;q=file+extension+php');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(9) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `username`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'admin', 'admin@gmail.com', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `notify_db`
--

CREATE TABLE `notify_db` (
  `n_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `userName` varchar(200) NOT NULL,
  `videoType` varchar(200) NOT NULL,
  `videoTitle` varchar(200) NOT NULL,
  `videoUrl` varchar(400) NOT NULL,
  `videoId` varchar(100) NOT NULL,
  `videoDuration` varchar(50) NOT NULL,
  `tags` varchar(200) NOT NULL,
  `totalViews` bigint(20) NOT NULL,
  `cid` int(11) NOT NULL,
  `categoryName` varchar(200) NOT NULL,
  `ThumbImage` varchar(400) NOT NULL,
  `downloads` bigint(20) NOT NULL,
  `fileSize` bigint(20) NOT NULL,
  `type` varchar(200) NOT NULL,
  `image` varchar(400) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `firebase_token` text NOT NULL,
  `firebase_api` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `qty` int(5) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sdk_type`
--

CREATE TABLE `sdk_type` (
  `sdk_id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sdk_type`
--

INSERT INTO `sdk_type` (`sdk_id`, `type`) VALUES
(1, 'theme'),
(2, 'videofx'),
(3, 'animatedsticker'),
(4, 'captionstyle'),
(5, 'facesticker'),
(6, 'font'),
(7, 'funsticker'),
(8, 'music'),
(9, 'partical'),
(10, 'scene'),
(11, 'videotransition');

-- --------------------------------------------------------

--
-- Table structure for table `shayari`
--

CREATE TABLE `shayari` (
  `id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `shayari` text NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `tags` varchar(100) NOT NULL,
  `views` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shayari`
--

INSERT INTO `shayari` (`id`, `c_id`, `date`, `shayari`, `c_name`, `tags`, `views`) VALUES
(1, 0, '0000-00-00', 'Sambhale Nahi Sambhalta Hai Dil, Mohabbat Ki Tapish Se Na Jala, Ishq TalabGaar Hai Tera Chala Aa, Ab Zamane Ka Bahaana Na Bana.', '2', 'romentic', 0),
(2, 0, '0000-00-00', 'Mohabbat Naam Hai Jiska Wo Aisi Qaid Hai Yaaro, Ki Umrein Beet Jaati Hain Sazaa Puri Nahin Hoti.', '2', 'romentic', 0),
(3, 0, '0000-00-00', 'Sambhale Nahi Sambhalta Hai Dil, Mohabbat Ki Tapish Se Na Jala, Ishq TalabGaar Hai Tera Chala Aa, Ab Zamane Ka Bahaana Na Bana.', '', 'abc', 0),
(4, 0, '0000-00-00', 'Mohabbat Naam Hai Jiska Wo Aisi Qaid Hai Yaaro, Ki Umrein Beet Jaati Hain Sazaa Puri Nahin Hoti.', '', 'xyz', 0),
(5, 0, '0000-00-00', 'Sambhale Nahi Sambhalta Hai Dil, Mohabbat Ki Tapish Se Na Jala, Ishq TalabGaar Hai Tera Chala Aa, Ab Zamane Ka Bahaana Na Bana.', '2', 'xyz', 0),
(6, 0, '0000-00-00', 'Mohabbat Naam Hai Jiska Wo Aisi Qaid Hai Yaaro, Ki Umrein Beet Jaati Hain Sazaa Puri Nahin Hoti.', '1', 'xyz', 0),
(7, 0, '0000-00-00', 'Dil se roye magar honto se muskura beithe,\nyunhi hum kisi se wafa nibha beithe,\nwo hame ek lamha na de paye apne pyar ka,\naur hum unke liye apni zindagi gawa beithe.', 'Love', '', 0),
(8, 0, '0000-00-00', 'Kashish toh bahut hai mere pyar mai,\nLekin koi hai pathar dil jo pigalta nahi,\nAgar mile khuda to mangungi usko,\nSuna hai khuda marne se pehle milte nahi.', 'Sad', '', 0),
(9, 0, '0000-00-00', '', 'Love', '', 0),
(10, 0, '0000-00-00', '', 'Love', '', 0),
(11, 0, '0000-00-00', 'hii', 'Love', '', 0),
(12, 0, '0000-00-00', '', 'Love', '', 0),
(13, 0, '0000-00-00', 'Mohabbat Naam Hai Jiska Wo Aisi Qaid Hai Yaaro, Ki Umrein Beet Jaati Hain Sazaa Puri Nahin Hoti.', 'Love', '', 0),
(14, 0, '0000-00-00', 'hello how r u .....', 'Love', '', 0),
(15, 0, '0000-00-00', '', 'Love', '', 0),
(16, 0, '0000-00-00', '', 'Love', '', 0),
(17, 0, '0000-00-00', 'Hello How r u..', 'Love', '', 0),
(18, 0, '0000-00-00', 'how r u', 'Love', '', 0),
(19, 0, '0000-00-00', 'Mohabbat Naam Hai Jiska Wo Aisi Qaid Hai Yaaro, Ki Umrein Beet Jaati Hain Sazaa Puri Nahin Hoti.', 'Love', '', 0),
(20, 0, '0000-00-00', 'Mohabbat Naam Hai Jiska Wo Aisi Qaid Hai Yaaro, Ki Umrein Beet Jaati Hain Sazaa Puri Nahin Hoti.', 'Love', '', 0),
(21, 0, '0000-00-00', 'good morning', 'Good Morning', '', 0),
(22, 0, '0000-00-00', 'Good morning', 'Good Morning', '', 0),
(23, 0, '0000-00-00', 'Hello', 'Love', '', 0),
(24, 0, '0000-00-00', 'Helooo', 'motivational', '', 0),
(25, 0, '0000-00-00', 'nnajaak', 'Love', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shayari_cat`
--

CREATE TABLE `shayari_cat` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `c_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shayari_cat`
--

INSERT INTO `shayari_cat` (`c_id`, `c_name`, `c_image`) VALUES
(1, 'Birthday', 'happy_birthday_photo_frame_background_vector_549182.jpg'),
(2, 'Romentic', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_api_fetch_url`
--

CREATE TABLE `tbl_api_fetch_url` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `link` text NOT NULL,
  `token` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_api_fetch_url`
--

INSERT INTO `tbl_api_fetch_url` (`id`, `name`, `link`, `token`) VALUES
(1, 'insta IGTV', 'http://rollaapps.net/api/v1/check-link', 'YWs0WWJZMjl0TGJoNWRuWnBaR1Z2TG1SdmQyNXNiMkZrWlhJdVptOXlMbWxuZEhZdVlYQndpQTdrPT0='),
(2, 'insta IGTV', 'http://rollaapps.net/api/v1/check-link', 'YWs0WWJZMjl0TGJoNWRuWnBaR1Z2TG1SdmQyNXNiMkZrWlhJdVptOXlMbWxuZEhZdVlYQndpQTdrPT0=');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_name`
--

CREATE TABLE `tbl_name` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_name`
--

INSERT INTO `tbl_name` (`id`, `name`) VALUES
(0, 'sdvsdf'),
(0, 'sdfd');

-- --------------------------------------------------------

--
-- Table structure for table `videofeedback`
--

CREATE TABLE `videofeedback` (
  `f_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videofeedback`
--

INSERT INTO `videofeedback` (`f_id`, `name`, `email`, `message`) VALUES
(1, 'abc', 'abc.ab@gmail.com', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `videoreport`
--

CREATE TABLE `videoreport` (
  `v_id` int(11) NOT NULL,
  `video_name` varchar(200) NOT NULL,
  `user_message` varchar(400) NOT NULL,
  `device_info` varchar(300) NOT NULL,
  `reply` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videoreport`
--

INSERT INTO `videoreport` (`v_id`, `video_name`, `user_message`, `device_info`, `reply`) VALUES
(1, 'Katal agar karna ho new song', 'video cant be play', 'version 5.0 device Mi', ''),
(2, 'Katal agar karna ho new song1', 'video cant be play....', 'version 5.0 device Mi', '');

-- --------------------------------------------------------

--
-- Table structure for table `video_sdk`
--

CREATE TABLE `video_sdk` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `tags` varchar(300) NOT NULL,
  `version` float NOT NULL,
  `minAppVersion` float NOT NULL,
  `packageUrl` varchar(300) NOT NULL,
  `packageSize` int(11) NOT NULL,
  `coverUrl` varchar(300) NOT NULL,
  `supportedAspectRatio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video_sdk`
--

INSERT INTO `video_sdk` (`id`, `name`, `category`, `description`, `tags`, `version`, `minAppVersion`, `packageUrl`, `packageSize`, `coverUrl`, `supportedAspectRatio`) VALUES
(1, 'xdl', '', '', 'szf', 0, 0, 'lyricvid/material/package_201808291343.torrent', 9, 'lyricvid/material/package_201808291343.png', 0),
(2, 'abc', '', '', 'sd', 0, 0, 'lyricvid/material/theme/package_201808291356.torrent', 10, 'lyricvid/material/theme/coverpackage_201808291356.png', 0),
(3, 'abc', '', '', 'sd', 0, 0, 'lyricvid/material/theme/package_201808291357.torrent', 10, 'lyricvid/material/theme/cover/package_201808291357.png', 0),
(4, 'sdfDSFS', '4', 'SFSF', 'DFd', 1, 2, 'lyricvid/material/captionstyle/package_201808291400.torrent', 21, 'lyricvid/material/captionstyle/cover/package_201808291400.png', 0),
(5, 'insta IGTV', '', '', '', 0, 0, '', 0, '', 0),
(6, 'insta IGTV', '', '', '', 0, 0, '', 0, '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_group_id`
--
ALTER TABLE `add_group_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `appdata`
--
ALTER TABLE `appdata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appdetails`
--
ALTER TABLE `appdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_category`
--
ALTER TABLE `app_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `app_download_details`
--
ALTER TABLE `app_download_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_group_cat`
--
ALTER TABLE `app_group_cat`
  ADD PRIMARY KEY (`g_id`);

--
-- Indexes for table `audio`
--
ALTER TABLE `audio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `date_filter`
--
ALTER TABLE `date_filter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `developer`
--
ALTER TABLE `developer`
  ADD PRIMARY KEY (`dev_id`);

--
-- Indexes for table `dynamic_page`
--
ALTER TABLE `dynamic_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notify_db`
--
ALTER TABLE `notify_db`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_products_1` (`login_id`);

--
-- Indexes for table `sdk_type`
--
ALTER TABLE `sdk_type`
  ADD PRIMARY KEY (`sdk_id`);

--
-- Indexes for table `shayari`
--
ALTER TABLE `shayari`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shayari_cat`
--
ALTER TABLE `shayari_cat`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_api_fetch_url`
--
ALTER TABLE `tbl_api_fetch_url`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videofeedback`
--
ALTER TABLE `videofeedback`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `videoreport`
--
ALTER TABLE `videoreport`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `video_sdk`
--
ALTER TABLE `video_sdk`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_group_id`
--
ALTER TABLE `add_group_id`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `appdata`
--
ALTER TABLE `appdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `appdetails`
--
ALTER TABLE `appdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_category`
--
ALTER TABLE `app_category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `app_download_details`
--
ALTER TABLE `app_download_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `app_group_cat`
--
ALTER TABLE `app_group_cat`
  MODIFY `g_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `audio`
--
ALTER TABLE `audio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `date_filter`
--
ALTER TABLE `date_filter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `developer`
--
ALTER TABLE `developer`
  MODIFY `dev_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `dynamic_page`
--
ALTER TABLE `dynamic_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notify_db`
--
ALTER TABLE `notify_db`
  MODIFY `n_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sdk_type`
--
ALTER TABLE `sdk_type`
  MODIFY `sdk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `shayari`
--
ALTER TABLE `shayari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `shayari_cat`
--
ALTER TABLE `shayari_cat`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_api_fetch_url`
--
ALTER TABLE `tbl_api_fetch_url`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `videofeedback`
--
ALTER TABLE `videofeedback`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `videoreport`
--
ALTER TABLE `videoreport`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `video_sdk`
--
ALTER TABLE `video_sdk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_products_1` FOREIGN KEY (`login_id`) REFERENCES `login` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
