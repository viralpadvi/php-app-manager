<?php
interface interface1
{
    function insert($table,$value);
}
?>