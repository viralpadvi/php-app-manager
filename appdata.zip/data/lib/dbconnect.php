<?php

class dbconnect
{
    function connect()
    {
        $connection=mysqli_connect("localhost","appdevdb","root@123","appdevnew");
				return $connection;
    }
}
?>