 <?php 
/* header('location:ewfrwer');
    exit();*/
	 include '../common/a.php'; 
     ?>