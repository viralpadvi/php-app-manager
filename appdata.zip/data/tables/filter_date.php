<?php include '../common/header.php'; ?>
<?php include '../common/sidebar.php'; ?>

 
<div class="content">
<div class="row">
    <div class="col-md-10 ml-auto mr-auto">
      <div class="page-categories">
       <!--  <h3 class="title text-center">Page Subcategories</h3>
        <br /> -->
        <ul class="nav nav-pills nav-pills-warning nav-pills-icons justify-content-center" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#link7" role="tablist">
              <i class="material-icons">T </i> Today Report
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#link8" role="tablist">
              <i class="material-icons">Y</i> Yesterday
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#link9" role="tablist">
              <i class="material-icons">TW</i> This Week
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#link10" role="tablist">
              <i class="material-icons">TM</i> This Month
            </a>
          </li>
        </ul>
        <div class="tab-content tab-space tab-subcategories">
          <div class="tab-pane active" id="link7">
            <div class="card">
              <div class="card-header"><!-- 
                <h4 class="card-title">Description about product</h4> -->
                <p class="card-category"> 
                </p>
              </div>
              <!-- start -->
              <div class="card-body"> 
        <div style="overflow-x:auto;">
        <table id="table1" class="table table-bordered table-striped datatable">
          <thead>
            <tr>
              <th>#</th>
              <th>App_ID</th>
              <th>app name</th>
              <th>downoads</th>
              <th>date</th>
          
            </tr>
          </thead>
          <tbody>
            <div id="topic_group">
            <tr>
              <?php 
        echo $curdate=date('Y-m-d');
            $i=1;
            $q=$d->select("date_filter,appdetails ","date_filter.app_id=appdetails.app_id AND date_filter.today_date= CURDATE()","");
          while($row=mysqli_fetch_array($q)) {
             ?>
              <td><?php echo $i++; ?></td>
              <td ><?php echo $row['app_id'] ?></td>
              <td ><?php echo $row['app_name'] ?></td>
               <td><?php echo $row['download'] ?></td>
              <td><?php echo $row['today_date'] ?></td>

            </tr>
          <?php } ?>
          </div>
         
          </tbody>
        </table>
        </div>
     
      <!-- /.box-body -->
              </div>
            </div>
          </div>
          <div class="tab-pane" id="link8">
            <div class="card">
            
              <div class="card-body">

               <div style="overflow-x:auto;">
        <table id="table1" class="table table-bordered table-striped datatable">
          <thead>
            <tr>
              <th>#</th>
              <th>App_ID</th>
              <th>app name</th>
              <th>downoads</th>
              <th>date</th>
            
            </tr>
          </thead>
          <tbody>
            <div id="topic_group">
            <tr>
              <?php  
            $i=1;
            $q=$d->select("date_filter,appdetails","date_filter.app_id=appdetails.app_id AND date_filter.today_date = CURDATE()-1");
          while($row=mysqli_fetch_array($q)) {
             ?>
              <td><?php echo $i++; ?></td>
              <td ><?php echo $row['app_id'] ?></td>
              <td ><?php echo $row['app_name'] ?></td>
               <td><?php echo $row['download'] ?></td>
              <td><?php echo $row['today_date'] ?></td>

            </tr>
          <?php } ?>
          </div>
         
          </tbody>
        </table>
        </div> 
              </div>
            </div>
          </div>
          <div class="tab-pane" id="link9">
            <div class="card">
             
              <div class="card-body">
               <div style="overflow-x:auto;">
        <table id="table1" class="table table-bordered table-striped datatable">
          <thead>
            <tr>
              <th>#</th>
              <th>App_ID</th>
              <th>app name</th>
              <th>downoads</th>
              <th>date</th>
              
            </tr>
          </thead>
          <tbody>
            <div id="topic_group">
            <tr>
              <?php  
            $i=1;
            /*$q=$d->select("date_filter,appdetails","date_filter.app_id=appdetails.app_id GROUP BY appdetails.app_id");
          while($row=mysqli_fetch_array($q)) {

*/  if($_SERVER['HTTP_HOST']=="localhost" or $_SERVER['HTTP_HOST']=="192.168.1.125")
    { 
      //local  

         DEFINE ('DB_USER', 'appdevdb');
         DEFINE ('DB_PASSWORD', 'root@123');
         DEFINE ('DB_HOST', 'localhost'); //host name depends on server
         DEFINE ('DB_NAME', 'appdevnew');
    }
    else
    {
      //local live 

       DEFINE ('DB_USER', 'appdevdb');
       DEFINE ('DB_PASSWORD', 'root@123');
       DEFINE ('DB_HOST', 'localhost'); //host name depends on server
       DEFINE ('DB_NAME', 'appdevnew');
    } 

    
    $mysqli =mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

    if ($mysqli->connect_errno) 
    {
        echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }
    $query = "SELECT date_filter.app_id,appdetails.app_name, SUM(download) FROM date_filter LEFT JOIN appdetails ON appdetails.app_id = date_filter.app_id WHERE date_filter.today_date BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE() GROUP BY date_filter.app_id"; 
         
      $sql = mysqli_query($mysqli,$query)or die(mysqli_error());

      // Print out result
      while($row = mysqli_fetch_assoc($sql)){

     ?>
              <td><?php echo $i++; ?></td>
              <td ><?php echo $row['app_id'] ?></td>
              <td ><?php echo $row['app_name'] ?></td>
               <td><?php echo $row['SUM(download)'] ?></td>
              <td><?php ?></td>

            </tr>
          <?php } ?>
          </div>
         
          </tbody>
        </table>
        </div>
              </div>
            </div>
          </div>
          <div class="tab-pane" id="link10">
            <div class="card">
           
             <!--  <div class="card-body">
              <div style="overflow-x:auto;">
        <table id="table1" class="table table-bordered table-striped datatable">
          <thead>
            <tr>
              <th>#</th>
              <th>App_ID</th>
              <th>app name</th>
              <th>downoads</th>
              <th>date</th>
              
            </tr>
          </thead>
          <tbody>
            <div id="topic_group">
            <tr>
              <?php  
            $i=1;
            $q=$d->select("date_filter,appdetails","date_filter.app_id=appdetails.app_id AND date_filter.today_date BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE()");
          while($row=mysqli_fetch_array($q)) {
             ?>
              <td><?php echo $i++; ?></td>
              <td ><?php echo $row['app_id'] ?></td>
              <td ><?php echo $row['app_name'] ?></td>
               <td><?php echo $row['download'] ?></td>
              <td><?php echo $row['today_date'] ?></td>

            </tr>
          <?php } ?>
          </div>
         
          </tbody>
        </table>
        </div> 
              </div> -->

              <div class="card-body">
          <div class="toolbar">
            <!--        Here you can write extra buttons/actions for the toolbar              -->
          </div>
          <div class="material-datatables">
            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
              <thead>
                <tr>
                    <th>#</th>
              <th>App_ID</th>
              <th>app name</th>
              <th>downoads</th>
              <th>date</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                <th>#</th>
              <th>App_ID</th>
              <th>app name</th>
              <th>downoads</th>
              <th>date</th>
                </tr>
              </tfoot>
              <tbody>
                  <?php  
            $i=1;
            $q=$d->select("date_filter,appdetails","date_filter.app_id=appdetails.app_id AND date_filter.today_date BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE()");
          while($row=mysqli_fetch_array($q)) {
             ?>
             <tr>
              <td><?php echo $i++; ?></td>
              <td ><?php echo $row['app_id'] ?></td>
              <td ><?php echo $row['app_name'] ?></td>
               <td><?php echo $row['download'] ?></td>
              <td><?php echo $row['today_date'] ?></td>

            </tr>
          <?php } ?>
                
              </tbody>
            </table>
          </div>
        </div>
        <!-- end content-->
      </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


<?php include '../../data/common/footer.php'; ?>